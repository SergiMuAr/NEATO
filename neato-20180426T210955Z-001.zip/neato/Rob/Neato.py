#!/usr/bin/python
#coding: utf8

"""
Imports
"""
import time

"""
Imports de Teclado
"""
import os, sys
import tty
from select import select
import time

import math

"""
Imports de Procesos
"""
from multiprocessing import Process, Queue

import p_Communication as p_Communication
import p_OdometryLaser as p_OdometryLaser
import p_Plot as p_Plot

"""
Clase para recoger solo una tecla sin enter.
"""
class _Getch:

    def __init__(self):
    
        import tty, sys

    def __call__(self):
    
        import sys, tty, termios
    
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
    
        try:
    
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
    
        finally:
    
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            
    	print ch
        return ch

# Main
def main():

    # Parametros Robot.
	S = 121.5		# en mm
	distancia_L = 0	# en mm
	distancia_R = 0	# en mm
	speed = 0 		# en mm/s
	tita_dot = 0
	tiempo = 5		
	direccion = 0

	# Creamos las pipes de comunicacion para los procesos.
	# Pipes para el proceso de Comunicaciones.
	in_pC = Queue()
	out_pC = Queue()

	# Pipe para el proceso de Plotear.
	in_pP = Queue()	

	# Creamos los procesos.
	print 'Create Processes.'
	p_comunicaciones = Process(target=p_Communication.run, args=(in_pC, out_pC,))
	p_odometriaLaser = Process(target=p_OdometryLaser.run, args=(out_pC, in_pC, in_pP,))
	p_plot = Process(target=p_Plot.run, args=(in_pP,))
	
	# Ejecutamos los procesos.
	print 'Start Processes.'
	p_comunicaciones.start()
	p_odometriaLaser.start()
	p_plot.start()

	# Envio de la S
	out_pC.put(S)

	# Esperamos a inicializar procesos.
	print 'Wait for processes.'
	time.sleep(5);

	# Terminal para leer del teclado
	in_key = _Getch()

	print "########################"
	print "Speed = " + str(speed)
	print "Tita_dot = " + str(tita_dot)

	if direccion == 0:
		print "Direction: fordward."
	else:
		print "Direction: backward."

	print "q to exit."
	print "########################"

	# Tecla a leer.
	tecla = ''
	comando = ''
	
	while tecla != "q":

		# Leemos la tecla.
		print "Write command: "       
		tecla = in_key()

		if tecla == '8' or tecla == '2':

			if tecla == '8':
				speed = 50
			else:
				speed = -50

			if speed >= 0:
				direccion = 0
			else:
				direccion = 1

			if speed == 0:
			
				comando = 'SetMotor LWheelDisable RWheelDisable'
				in_pC.put(comando)
				comando = 'SetMotor RWheelEnable LWheelEnable'
				in_pC.put(comando)
			
			else:

				#distancia_R = (((speed * pow(-1, direccion) ) + (S * tita_dot)) * tiempo) * pow(-1, direccion)
				#distancia_L = (((speed * pow(-1, direccion) ) + (-S * tita_dot)) * tiempo) * pow(-1, direccion)
                                distancia_R = (((speed * pow(-1, direccion) ) * tiempo) * pow(-1, direccion))
				distancia_L = (((speed * pow(-1, direccion) ) * tiempo) * pow(-1, direccion))
                                print "distancia R " + str(distancia_R)
                                print "distancia L " + str(distancia_L)
				comando = 'SetMotor LWheelDist ' + str(distancia_L) + ' RWheelDist ' + str(distancia_R) + ' Speed ' + str(speed * pow(-1, direccion))
				in_pC.put(comando)
                          

		elif tecla == '4' or tecla == '6':

			if tecla == '4':
				#tita_dot = tita_dot + (3.1415/10)
                                tita_dot = (3.1415/10)
                                direccion = 0
			else:
				#tita_dot = tita_dot - (3.1415/10)
                                tita_dot = -(3.1415/10)
                                direccion = 1

			#distancia_R = (((speed * pow(-1, direccion) ) + (S * tita_dot)) * tiempo) * pow(-1, direccion)
			#distancia_L = (((speed * pow(-1, direccion) ) + (-S * tita_dot)) * tiempo) * pow(-1, direccion)
                        distancia_R = -(0.5*math.pi*S)*pow(-1, direccion)
                        distancia_L = (0.5*math.pi*S)*pow(-1, direccion)
                        print "distancia l " + str(-(0.5*math.pi*S))
			#comando = 'SetMotor LWheelDist ' + str(distancia_L) + ' RWheelDist ' + str(distancia_R) + ' Speed ' + str(speed * pow(-1, direccion))
  			comando = 'SetMotor LWheelDist ' + str(distancia_L) + ' RWheelDist ' + str(distancia_R) + ' Speed ' + str(50)
                      
			in_pC.put(comando)

		elif tecla == '5':

			direccion = 0
			speed = 0
			tita_dot = 0
			distancia_L = 0
			distancia_R = 0

			comando = 'SetMotor LWheelDisable RWheelDisable'
			in_pC.put(comando)
			comando = 'SetMotor RWheelEnable LWheelEnable'
			in_pC.put(comando)

		elif tecla == '1' or tecla == '3':

			if tecla == '1':
				distancia_R = 1000 * tiempo				
			else:
				distancia_R = -1000 * tiempo

			distancia_L = -distancia_R
			
			if speed == 0:
				speed = 50

			comando = 'SetMotor LWheelDist ' + str(distancia_L) + ' RWheelDist ' + str(distancia_R) + ' Speed ' + str(speed * pow(-1, direccion))
                        #comando = 'SetMotor LWheelDist ' + str(distancia_L) + ' RWheelDist ' + str(distancia_R)

			in_pC.put(comando)

		elif tecla == 'b':

			in_pP.put('borrar')
			print "########################"
			print "Delete map."
			print "q to exit."
			print "########################"

		elif tecla == 'l':

			in_pC.put('Laser')
			print "########################"
			print "Laser."
			print "q to exit."
			print "########################"
                elif tecla == 'm':
                        comando = 'SetMotor LWheelDist ' + str(1000) + ' RWheelDist ' + str(1000) + ' Speed ' + str(50)
			in_pC.put(comando)
		if tecla == '8' or tecla == '2' or tecla == '6' or tecla == '4' or tecla == '5' or tecla == '1' or tecla == '3':
			
			#print "\n########################"
			#print 'Comando enviado: ' + comando
			print "########################"
			print "Speed = " + str(speed)
			print "Tita_dot = " + str(tita_dot)

			if direccion == 0:
				print "Direction: fordward."
			else:
				print "Direction: backward."

			print "q to exit."
			print "########################"

		#print("\033[6;3HHello")



	# Enviamos mensajes para finalizar los procesos.	
	in_pC.put('quit')
	out_pC.put('quit')
	
	# Esperar a que finalice.
	p_comunicaciones.join()
	p_odometriaLaser.join()

	print "########################"
	print "q to close Plot."
	print "########################"
	tecla = ''
	while tecla != "q":
		# Leemos la tecla.
		print "Write command: "       
		tecla = in_key()

	in_pP.put('quit')

	# Esperar a que finalice.
	p_plot.join()

	print "\n\n-- END --\n"

# Llamada a la funcion main
if __name__ == '__main__':

    main()
