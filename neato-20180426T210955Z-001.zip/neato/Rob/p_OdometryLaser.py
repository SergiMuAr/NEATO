#!/usr/bin/python
#coding: utf8

"""
Imports de Procesos
"""
"""
Imports
"""
import time

import math

"""
Imports de Procesos
"""
from multiprocessing import Queue
from Queue import Empty



queue_in_g = Queue()
queue_out_g = Queue()
queue_out2_g = Queue()

def inicializar(rbuffer):
	result = []
    	split = rbuffer.split()
    	split_left = split[6].split(",", 1)
    	split_right = split[10].split(",", 1)

    	posR = int(split_right[1])
    	posL = int(split_left[1])
	
	result = []
	result.append(posR)
	result.append(posL)
	return result



def get_odometry(rbuffer, pose, posR, posL):
    #import math
    result = []
    split = rbuffer.split()
    split_left = split[6].split(",", 1)
    split_right = split[10].split(",", 1)
    result.append(int(split_left[1]))
    result.append(int(split_right[1]))

    distancia_R = int(split_right[1])-posR
    distancia_L = int(split_left[1])-posL

    C = (distancia_R+distancia_L)/2
    titaInc = 0
    if (abs(distancia_R - distancia_L) > 5):
	titaInc = (distancia_R - distancia_L)/(2*121.5)
    else:
	titaInc = 0
    pose[0] = pose[0] + C*math.cos(pose[2]) 
    pose[1] = pose[1] + C*math.sin(pose[2])
    pose[2] = (pose[2] + titaInc)%(2*math.pi)
    #print "PoseX = " + str(pose[0])
    #print "PoseY = " + str(pose[1])
    #print "PoseTita = " + str(pose[2])
    #print "Grados = " + str(pose[2]*180/math.pi)

    posR = int(split_right[1])
    posL = int(split_left[1])
	
    result.append(pose)
    #print result
    return result

    #print result
    
def laser_calc(msg, pose, queue_test):
       #print msg
       result = []
       tmp = msg.split(",")
       print " dist en angle 0 : " + str(tmp[4])
       for i in range(1, 361):
              dist = int(tmp[3*i + 1])
              if (dist > 0 and dist <= 6000):
                      result.append(pose[0]-95+dist*math.cos(math.radians(i - 1) + pose[2])) 
                      result.append(pose[1]+dist*math.sin(math.radians(i - 1) + pose[2]))
                      if ((i < 46 or i > 314) and dist < 10):
                              comando = 'SetMotor LWheelDisable RWheelDisable'
                              queue_test.put(comando)
                              comando = 'SetMotor LWheelEnable RWheelEnable'
                              queue_test.put(comando)
                      '''print " "
                      print dist
                      print pose[0]+dist*math.cos((i-1)*180/math.pi)
                      print pose[1]+dist*math.sin((i-1)*180/math.pi)'''       
       return result 


def run(queue_in, queue_out, queue_out2):
	
    	global queue_in_g
    	global queue_out_g
    	global queue_out2_g
    	queue_in_g = queue_in
    	queue_out_g = queue_out
    	queue_out2_g = queue_out2
    
	print "#### Start OdometryLaser Process."
	
	S = float(queue_in.get())
	print "#### OdometryLaser Process: S = " + str(S)

	print '#### OdometryLaser Process: Started.'
	
	x_r_last = 999.9
	y_r_last = 999.9
	tita_dot = 0
        n_times_odo = 0
        n_times_laser = 0

	queue_out.put('Odo')
	pose = []
	pose.append(0)
	pose.append(0)
	pose.append(0)

	result = inicializar(queue_in.get())	
	posR = result[1]
	posL = result[0]
	
	while True:

		try:
			
			msg = queue_in.get()
			#msg = queue_in.get_nowait()
			#start_total = time.time()

		except Empty:
			
			#print '#### OdometryLaser Process: Nothing.'
			pass
		
		else:
            
			#print "#### OdometryLaser Process: msg -> " + msg

			if msg == 'quit':
				
				break

			elif msg[0] == 'O':
				n_times_odo = n_times_odo + 1
				# ODO
				msg = msg[1:]
				#print msg
				
				x_r = 0 # Pos X robot
				y_r = 0 # Pos Y robot

				pos_robot = [] # Vector of 2 positions (x, y of robot)
				
				#########################################################################################################################				
			# AFEGIR AQUI CODI ODOMETRIA
				
				x_r_last = pose[0]
				y_r_last = pose[1]
                
                                print "dins de odo\n"
		        	result =  get_odometry(msg, pose, posR, posL)
				posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                
                                queue_out.put('Laser')
				'''pos_robot.append(result[0])
				pos_robot.append(result[1])
				
				x_r = pose[0]
				y_r = pose[1]'''
			#########################################################################################################################
				
				if x_r_last != x_r and y_r_last != y_r:
					
					queue_out2.put(pos_robot)
					x_r_last = x_r
					y_r_last = y_r
                                '''if n_times_odo > 10:
                                        queue_out.put('Laser')
                                        n_times_odo = 0
                                else:
                                        queue_out.put('Odo')'''
                                
			
			elif msg[0] == 'L':
                                n_times_laser = n_times_laser +1 
				# Laser
				msg = msg[1:]
				#print msg

				 
				datos_laser = [] # Vector of 720 or fewer positions always but always pair (x, y)
				#########################################################################################################################
				
				# AFEGIR AQUI LA RECONSTRUCIÓ INFORMACIÓ LASER
                                
                                datos_laser = laser_calc(msg, pose, queue_out)
				
				#########################################################################################################################
                                
				queue_out2.put(datos_laser)
                                if(n_times_laser >10):
                                        queue_out.put('Odo')
                                        n_times_laser = 0
                                else:
                                        queue_out.put('Laser')
			
			#queue_out.put('Odo')
			#time.sleep(1.75)
			#print "\nTiempo Total p_OdometryLaser: " + str(time.time() - start_total) + " segundos.\n"
			#print "p_odometryLaser"
                #print pose
	print "#### Finished OdometryLaser Process."
