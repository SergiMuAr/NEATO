#!/usr/bin/python
#coding: utf8

"""
Imports de Procesos
"""
"""
Imports
"""
import time

import math

"""
Imports de Procesos
"""
from multiprocessing import Queue
from Queue import Empty



queue_in_g = Queue()
queue_out_g = Queue()
queue_out2_g = Queue()

#Get left and right wheel position at the beginning
def inicializar(rbuffer):
	result = []
    	split = rbuffer.split()
    	split_left = split[6].split(",", 1)
    	split_right = split[10].split(",", 1)

    	posR = int(split_right[1])
    	posL = int(split_left[1])
	
	result = []
	result.append(posR)
	result.append(posL)
	return result


#Odometry calculation
def get_odometry(rbuffer, pose, posR, posL):
    result = []
    split = rbuffer.split()
    split_left = split[6].split(",", 1)
    split_right = split[10].split(",", 1)
    result.append(int(split_left[1]))
    result.append(int(split_right[1]))

    distancia_R = int(split_right[1])-posR
    distancia_L = int(split_left[1])-posL

    C = (distancia_R+distancia_L)/2
    titaInc = (((distancia_R) - (distancia_L)))/(2*121.5)
    pose[0] = pose[0] + C*math.cos(pose[2]) 
    pose[1] = pose[1] + C*math.sin(pose[2])
    pose[2] = (pose[2] + titaInc)%(2*math.pi)

    posR = int(split_right[1])
    posL = int(split_left[1])
	
    result.append(pose)
    return result

#laser process    
def laser_calc(msg, pose):
       print msg
       result = []
       colision_d = True
       tmp = msg.split(',')
       #print " dist en angle 0 : " + str(tmp[4])
       min = 3000
       min_r = 2000
       min_l = 2000
       rot = -1
       angleTr = 400
       for i in range(1, 361):
              dist = int(tmp[3*i + 1])
              if (dist > 0 and dist <= 6000):
                      result.append(pose[0]-95+dist*math.cos(math.radians(i - 1) + pose[2])) 
                      result.append(pose[1]+dist*math.sin(math.radians(i - 1) + pose[2]))
                      #ANGLES COMPRESOS A LA PART DAVANTERA DEL ROBOT PER TAL DAVANÇAR ENDAVANT
                      if ((i <= 39 or i >= 338)):
                              #xChoque VARIABLE QUE CONTE AMPLITUD RESPECTE AL CENTRE DEL ROBOT DEL PUNT DETECTAT
                              xChoque = dist*math.sin(math.radians(i-1))
                              distR = abs(dist*math.cos(math.radians(i-1)))
                              # SI LAMPLITUD ES INFERIOR A LAMPLADA DEL ROBOT S'HA DETECTAT POSSIBLE COLISIO
                              if(xChoque < 170):
                                      #PUNT DE COLISIO A MENYS DEL MINIM DAVANÇAMENT, ATUREM AVANÇAMENT
                                      if(distR < 350):
                                              min = 0
                                      elif (distR < min and min != 0):
                                              min = distR
                                              #min = dist
                                              angleTr = i-1
                      #ANGLES COMPRESOS A LA PART ESQUERRA DEL ROBOT, CALCULEN LA DISTANCIA DEVASIO
                      elif ((i > 39 and i < 129)):
                               if(i< 90):
                                      xChoque = dist*math.cos(math.radians(i-1))
                                      #print "distancia angulo xoque " + str(dist) + " " + str(i-1) + " " + str(xChoque) + str(math.cos(math.radians(i-1))) + "\r\n" 
                                      if(xChoque < 170):
                                              if(abs(dist*math.sin(math.radians(i-1))) < 350):
                                                      min_r = 0
                                              elif (abs(dist*math.sin(math.radians(i-1))) < min_r and min_r != 0):
                                                      min_r = abs(dist*math.sin(math.radians(i-1)))
                               elif(i > 90):
                                      xChoque = abs(dist*math.sin(math.radians(i-1-90)))
                                      if(xChoque < 170):
                                              if(abs(dist*math.cos(math.radians(i-1 - 90))) < 350):
                                                      min_r = 0
                                              elif (abs(dist*math.cos(math.radians(i-1 - 90))) < min_r and min_r != 0):
                                                      min_r = abs(dist*math.cos(math.radians(i-1 - 90)))
                               else:
                                      if(dist < 350):
                                              min_r = 0
                                      elif (dist < min_r and min_r != 0):
                                              min_r = dist
                                              
                      #ANGLES COMPRESOS A LA PART DRETA DEL ROBOT, FETS PER EVADIR
                      elif ((i < 333 and i > 243)):
                               if(i > 270):
                                      #xChoque = abs(dist*math.cos(math.radians(360-i-1)))
                                      xChoque = abs(dist*math.sin(math.radians(i-271)))
                                      print "distancia angulo xoque " + str(abs(dist*math.cos(math.radians(i-271)))) + " " + str(i-1) + " " + str(xChoque) + str(math.sin(math.radians(360-i-1))) + "\r\n" 
                                      if(xChoque < 170):
                                              if(abs(dist*math.cos(math.radians(i-271))) < 350):
                                                      min_l = 0
                                              elif (abs(dist*math.cos(math.radians(i-271))) < min_l and min_l != 0):
                                                      min_l = abs(dist*math.cos(math.radians(i-271)))
                               elif(i < 270):
                                      xChoque = abs(dist*math.sin(math.radians(i-1-180)))
                                      if(xChoque < 170):
                                              if(abs(dist*math.sin(math.radians(i-1 - 180))) < 350):
                                                      min_l = 0
                                              elif (abs(dist*math.sin(math.radians(i-1 - 180))) < min_l and min_l != 0):
                                                      min_l = abs(dist*math.sin(math.radians(i-1 - 180)))
                               else:
                                      if(dist < 350):
                                              min_l = 0
                                      elif (dist < min_l and min_l != 0):
                                              min_l = dist
                                      
       print "distancia a avançar esquerra " + str(min_r) + "\r\n"
       print "distancia a avançar dreta " + str(min_l) + "\r\n"
                             
       #CODI PER CALCULAR LA DISTANCIA D'AVANÇAMENT, DE ROTACIO I SENTIT DE ROTACIO
       if (min != 0):
               min = math.fabs(min)-350
       if(min_r != 0 and min_l != 0):
               if(min_l > min_r):
                       min_r = min_l
                       rot = 1
       elif(min_l != 0):
               min_r = min_l
               rot = 1
       print "voy a girar a " + str(rot) + "\r\n"
       #if(min_r > 500):
               #min_r = 500
       print "puc avançar recte " + str(min) + "\r\n"
       if(min < 20):
               min = 0
       print "angle dist min " + str(angleTr)
       return result, min, rot, (min_r-350)
 
#Set the Neato's looking to the final point introduced by the user      
def rotateToPoint(pose, pointToGo, out_q): 
        print "Check function\r\n"
        print "Odo: " + str(pose[0]) + "," + str(pose[1]) + "," + str(pose[2]) + "\r\n"
        angleP = 0
        P_x = (pointToGo[0] - pose[0])
        P_y = (pointToGo[1] - pose[1])
        print "Odo: " + str(P_x) + "," + str(P_y) + "\r\n"
        if (P_x != 0 and P_y != 0):
                angleP = math.atan(float(math.fabs(P_y))/float(math.fabs(P_x)))
                print "Angle before: " + str(angleP) + "\r\n"
                angleP = (math.pi+angleP)*(P_x < 0)*(P_y < 0) + (math.pi - angleP) *(P_y > 0)*(P_x < 0) + ((math.pi*2)-angleP)*(P_x > 0)*(P_y < 0)
                if(angleP == 0):
                        angleP = math.atan(float(math.fabs(P_y))/float(math.fabs(P_x)))   
                print "Angle after: " + str(angleP) + "\r\n"
        else:
                if (P_x == 0):
                        if (P_y < 0):
                                angleP = math.pi*1.5
                        else:
                                angleP = math.pi*0.50
                elif (P_y == 0):
                        if (P_x < 0):
                                angleP = math.pi
        ang = (angleP - pose[2])
        distance = ang * 121.5   
       
        comando = 'SetMotor LWheelDist ' + str(-distance) + ' RWheelDist ' + str(distance) + ' Speed ' + str(50) + "\r\n"
        out_q.put(comando)    
        timeMoving =  math.fabs((distance/50) + 0.5)
        time.sleep(timeMoving)
        
	#Distance from Neato's position to the final point
        distToGo = math.hypot(P_x, P_y)
        return distToGo

#Move Neato the distance got by parameter
def moveToPoint(dist, out_q):
        speed = 200
        comando = 'SetMotor LWheelDist ' + str(dist) + ' RWheelDist ' + str(dist) + ' Speed ' + str(speed)
        out_q.put(comando)    
        timeMoving =  math.fabs((dist/speed) + 2)
        time.sleep(timeMoving)    

#Rotate Neato 90 degrees to the direction got by parameter	
def evadeFun(outq, sentido,dist):
        print "Evade entrat \r\n"
        distance = (0.5*math.pi*121.5)*sentido
        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(-distance) + ' Speed ' + str(50)
        cleanCua(outq)
        outq.put(comando)   
        timeMoving =  math.fabs((distance/50)) + 0.5
        time.sleep(timeMoving)
        print "Evade sortir\r\n"

#Main process function        
def run(queue_in, queue_out, queue_out2):
	
    	global queue_in_g
    	global queue_out_g
    	global queue_out2_g
    	queue_in_g = queue_in
    	queue_out_g = queue_out
    	queue_out2_g = queue_out2
    
	print "#### Start OdometryLaser Process."
	
	S = float(queue_in.get())
	print "#### OdometryLaser Process: S = " + str(S)

	print '#### OdometryLaser Process: Started.'
	
	x_r_last = 999.9
	y_r_last = 999.9
	tita_dot = 0
        n_times_odo = 0
        n_times_laser = 0
        datosLaser = []
        pos_robot = [0, 0]
        queue_out2.put(pos_robot)
        

	queue_out.put('Odo')
        #queue_out.put('Laser')
	pose = []
	pose.append(0)
	pose.append(0)
	pose.append(0)

	result = inicializar(queue_in.get())	
	posR = result[1]
	posL = result[0]
        timeGoing = 0
        timeEvading = 0
        
        #goToPoint = False
        #evadeTime = False
        last_msg_laser = ""
        pointToGo = []
        distToMove = 0
	
	while True:

		try:                                      
                        msg = queue_in.get() #Si es bloquejant no podem fer res                  
			#msg = queue_in.get_nowait()
			#start_total = time.time()
                        print str(msg) + "\r\n"

		except Empty:
			
			#print '#### OdometryLaser Process: Nothing.'
			pass
		
		else:
                
			#print "#### OdometryLaser Process: msg -> " + msg

			if msg == 'quit':
				
				break
                        elif len(msg) == 2:
                                print "Robot has changed its position"
                                time.sleep(msg[1])
                                queue_out.put('Odo')
                                
                        elif len(msg) == 3:
                                pointToGo = []
                                pointToGo.append(msg[0])
                                pointToGo.append(msg[1])
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                #Girar
                                distToGo = rotateToPoint(pose, pointToGo, queue_out)
                                
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                #Laser
                                queue_out.put('Laser')
                                msg = queue_in.get()
                                time.sleep(1)
                                datos_laser, distToMove, rotacion_sentido, evade_dist  = laser_calc(msg, pose)
                                if(distToGo < distToMove):
                                        distToMove = distToGo
                                queue_out2.put(datos_laser)
                                
                                if (distToMove != 0):
                                        moveToPoint(distToMove, queue_out)
                                queue_out.put('Bucle')
                                
                        elif len(msg) == 4:
                                print "Bucle\r\n"
                                
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                #Girar
                                distToGo = rotateToPoint(pose, pointToGo, queue_out)
                                
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                #Laser
                                queue_out.put('Laser')
                                msg = queue_in.get()
                                time.sleep(1)
                                datos_laser, distToMove, rotacion_sentido, evade_dist = laser_calc(msg, pose)
                                if(distToGo < distToMove):
                                        distToMove = distToGo
                                queue_out2.put(datos_laser)
                                
                                if (distToMove != 0):
                                        moveToPoint(distToMove, queue_out)
                                else:
                                        evadeFun(queue_out, rotacion_sentido, evade_dist)
                                        queue_out.put('Odo')
                                        print "Pose before" + str(pose) + "\r\n"
                                        msg = queue_in.get()
                                        
                                        #Odometria
                                        result = get_odometry(msg[1:], pose, posR, posL)
                                        posR = result[1]
                                        posL = result[0]
                                        pose = result[2]
                                        pos_robot = [pose[0], pose[1]]
                                        queue_out2.put(pos_robot)
                                        print "Pose after" + str(pose) + "\r\n"
                                        
                                        moveToPoint(evade_dist,queue_out)
                                
                                x_R = math.fabs(pose[0] - pointToGo[0])
                                y_R = math.fabs(pose[1] - pointToGo[1])
                                
                                if not(x_R <= 200 and y_R <= 200):
                                        queue_out.put('Bucle')
                                else:
                                        print "yalleghao\r\n"
                                        
			elif msg[0] == 'O':
                                print "Calculo odometria\r\n"
				n_times_odo = n_times_odo + 1
				# ODO
				msg = msg[1:]
				#print msg
				
				x_r = 0 # Pos X robot
				y_r = 0 # Pos Y robot

				pos_robot = [] # Vector of 2 positions (x, y of robot)
				
				#########################################################################################################################				
			# AFEGIR AQUI CODI ODOMETRIA
				
				x_r_last = pose[0]
				y_r_last = pose[1]
                
		        	result =  get_odometry(msg, pose, posR, posL)
				posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
			#########################################################################################################################                                
			
			elif msg[0] == 'L':
                                print "calculant laser \r\n"
				# Laser
				msg = msg[1:]
				#print msg

				 
				datos_laser = [] # Vector of 720 or fewer positions always but always pair (x, y)
				#########################################################################################################################
				
				# AFEGIR AQUI LA RECONSTRUCIÓ INFORMACIÓ LASER
                                
                                datos_laser, distToMove, rotacion_sentido, evade_dist  = laser_calc(msg, pose)
				queue_out2.put(datos_laser)
				#########################################################################################################################
                                                   
	print "#### Finished OdometryLaser Process."
