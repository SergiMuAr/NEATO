#!/usr/bin/python
#coding: utf8

"""
Imports
"""
import time

"""
Imports de Teclado
"""
import os, sys
import tty
from select import select
import time

import math

"""
Imports de Procesos
"""
from multiprocessing import Process, Queue

import p_Communication as p_Communication
import p_OdometryLaser as p_OdometryLaser
import p_Plot as p_Plot

"""
Clase para recoger solo una tecla sin enter.
"""
class _Getch:

    def __init__(self):
    
        import tty, sys

    def __call__(self):
    
        import sys, tty, termios
    
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
    
        try:
    
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
    
        finally:
    
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            
    	print ch
        return ch

# Main
def main():

    # Parametros Robot.
	S = 121.5		# en mm
	distancia_L = 0	# en mm
	distancia_R = 0	# en mm
	speed = 0 		# en mm/s
	tita_dot = 0
	tiempo = 5		
	direccion = 0
        moving = []
        moving.append(0) #Is moving or not
        moving.append(0) #Time will be moving

	# Creamos las pipes de comunicacion para los procesos.
	# Pipes para el proceso de Comunicaciones.
	in_pC = Queue()
	out_pC = Queue()

	# Pipe para el proceso de Plotear.
	in_pP = Queue()	

	# Creamos los procesos.
	print 'Create Processes.'
	p_comunicaciones = Process(target=p_Communication.run, args=(in_pC, out_pC,))
	p_odometriaLaser = Process(target=p_OdometryLaser.run, args=(out_pC, in_pC, in_pP,))
	p_plot = Process(target=p_Plot.run, args=(in_pP,))
	
	# Ejecutamos los procesos.
	print 'Start Processes.'
	p_comunicaciones.start()
	p_odometriaLaser.start()
	p_plot.start()

	# Envio de la S
	out_pC.put(S)

	# Esperamos a inicializar procesos.
	print 'Wait for processes.'
	time.sleep(5);

	# Terminal para leer del teclado
	in_key = _Getch()

	print "########################"
	print "Speed = " + str(speed)
	print "Tita_dot = " + str(tita_dot)

	if direccion == 0:
		print "Direction: fordward."
	else:
		print "Direction: backward."

	print "q to exit."
	print "########################"

	# Tecla a leer.
	tecla = ''
	comando = ''
	
	while tecla != "q":

		# Leemos la tecla.
		print "Write command: "       
		tecla = in_key()

		if tecla == '8' or tecla == '2':
                        if tecla == '8':
				direccion = 0
			else:
				direccion = 1
                        
                        print "Type a distance"
                        d = ''
                        tecla = in_key()
                        while (tecla >= '0' and tecla <= '9'):
                                d = d + tecla
                                tecla = in_key()                  
                              
                        if (d == ''):
                                distance = 200*pow(-1, direccion)
                        else:
                                distance = int(d)*pow(-1, direccion)                            
                        
                        print "Distance to move: " + str(distance)
							
			if speed == 0:
				comando = 'SetMotor LWheelDisable RWheelDisable'
				in_pC.put(comando)
				comando = 'SetMotor RWheelEnable LWheelEnable'
				in_pC.put(comando)
                                speed = 50			
			
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(distance) + ' Speed ' + str(speed)
                        in_pC.put(comando)
                        
                        #Robot is moving
                        moving = []
                        moving.append(0)
                        moving.append(int(d) / speed)
                        out_pC.put(moving)
			#Tell odometryLaser process that Neato is moving
                        
		elif tecla == '4' or tecla == '6':
			if tecla == '4':
                                direccion = 0 #Clockwise
			else:
                                direccion = 1 #Anticlockwise

			#Distance for 90 degrees
                        distance = (0.5*math.pi*S)
                        distancia_R = -(0.5*math.pi*S)*pow(-1, direccion)
                        distancia_L = (0.5*math.pi*S)*pow(-1, direccion)
  			comando = 'SetMotor LWheelDist ' + str(distancia_L) + ' RWheelDist ' + str(distancia_R) + ' Speed ' + str(50)
			in_pC.put(comando)
                        #Robot is moving
                        moving = []
                        moving.append(1)
                        if(speed == 0):
                                speed = 50
                        moving.append(distance / speed)
                        out_pC.put(moving)
			#Tell odometryLaser process that Neato is moving

		elif tecla == '5':
			#Stop moving
                        moving = 0
			direccion = 0
			speed = 0
			tita_dot = 0
			distancia_L = 0
			distancia_R = 0

			comando = 'SetMotor LWheelDisable RWheelDisable'
			in_pC.put(comando)
			comando = 'SetMotor RWheelEnable LWheelEnable'
			in_pC.put(comando)

		elif tecla == '1' or tecla == '3':
			if tecla == '1':
				distancia_R = 1000 * tiempo				
			else:
				distancia_R = -1000 * tiempo

			distancia_L = -distancia_R
			
			if speed == 0:
				speed = 50

			comando = 'SetMotor LWheelDist ' + str(distancia_L) + ' RWheelDist ' + str(distancia_R) + ' Speed ' + str(speed * pow(-1, direccion))

			in_pC.put(comando)

		elif tecla == 'b':
			#Delete laser map
			in_pP.put('borrar')
			print "########################"
			print "Delete map."
			print "q to exit."
			print "########################"

		elif tecla == 'l':
			#Call Neato's laser
			in_pC.put('Laser')
			print "########################"
			print "Laser."
			print "q to exit."
			print "########################"
                elif tecla == 's':
                        #Do a 1m square movement
                        if speed == 0:
                                '''comando = 'SetMotor LWheelDisable RWheelDisable'
                                in_pC.put(comando)'''
                                comando = 'SetMotor RWheelEnable LWheelEnable'
                                in_pC.put(comando)
                                speed = 50 
                              
                        #Move 1m
                        distance = 1000
                        timeMoving = (distance/speed) + 0.5
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(distance) + ' Speed ' + str(speed)
			in_pC.put(comando)
                        
                        moving = []
                        moving.append(1)
                        moving.append(timeMoving)
                        out_pC.put(moving)
                        time.sleep(timeMoving)
                        
                        #Turn 90 degrees
                        distance = (0.5*math.pi*S)
                        timeMoving = (distance/speed) + 0.5
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(-distance) + ' Speed ' + str(speed)
                        in_pC.put(comando)
                        
                        moving = []
                        moving.append(1)
                        moving.append(timeMoving)
                        out_pC.put(moving)
                        time.sleep(timeMoving)
                        
                        #Move 1m
                        distance = 1000
                        timeMoving = (1000/speed) + 0.5
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(distance) + ' Speed ' + str(speed)
			in_pC.put(comando)
                        
                        moving = []
                        moving.append(1)
                        moving.append(timeMoving)
                        out_pC.put(moving)
                        time.sleep(timeMoving)
                        
                        #Turn 90 degrees
                        distance = (0.5*math.pi*S) #90 degrees
                        timeMoving = (distance/speed) + 0.5
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(-distance) + ' Speed ' + str(speed)
                        in_pC.put(comando)
                        
                        moving = []
                        moving.append(1)
                        moving.append(timeMoving)
                        out_pC.put(moving)
                        time.sleep(timeMoving)
                        
                        #Move 1m
                        distance = 1000
                        timeMoving = (distance/speed) + 0.5
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(distance) + ' Speed ' + str(speed)
			in_pC.put(comando)
                        
                        moving = []
                        moving.append(1)
                        moving.append(timeMoving)
                        out_pC.put(moving)
                        time.sleep(timeMoving)
                        
                        #Turn 90 degrees
                        distance = (0.5*math.pi*S) #90 degrees
                        timeMoving = (distance/speed) + 0.5
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(-distance) + ' Speed ' + str(speed)
                        in_pC.put(comando)
                        
                        moving = []
                        moving.append(1)
                        moving.append(timeMoving)
                        out_pC.put(moving)
                        time.sleep(timeMoving)
                        
                        #Move 1m
                        distance = 1000
                        timeMoving = (distance/speed) + 0.5
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(distance) + ' Speed ' + str(speed)
			in_pC.put(comando)
                        
                        moving = []
                        moving.append(1)
                        moving.append(timeMoving)
                        out_pC.put(moving)
                        time.sleep(timeMoving)

                        #Turn 90 degrees
                        distance = (0.5*math.pi*S) #90 degrees
                        timeMoving = (distance/speed) + 0.5
                        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(-distance) + ' Speed ' + str(speed)
                        in_pC.put(comando)
                        
                        moving = []
                        moving.append(1)
                        moving.append(timeMoving)
                        out_pC.put(moving)
                        time.sleep(timeMoving)
                        
                elif tecla == 'g':
                        print "Go to a point"
                        print "Type x coordinate"
                        x_buffer = ''
                        tecla = in_key()
                        while ((tecla >= '0' and tecla <= '9') or tecla == '-' or tecla == '.'):
                                x_buffer = x_buffer + tecla
                                tecla = in_key()
                           
                        print "Type y coordinate"
                        y_buffer = ''
                        tecla = in_key()
                        while ((tecla >= '0' and tecla <= '9') or tecla == '-' or tecla == '.'):
                                y_buffer = y_buffer + tecla
                                tecla = in_key()
				
                        try:
                                xP = float(x_buffer)
                                yP = float(y_buffer)
                                print "Point: " + str(xP) + "," + str(yP)
                                pointToGo = []
                                pointToGo.append(xP*1000)
                                pointToGo.append(yP*1000)
                                pointToGo.append(0)
                                out_pC.put(pointToGo)
                        except ValueError:
                               print "Not a valid point. Try again\r\n" 
                                
                        
		if tecla == '8' or tecla == '2' or tecla == '6' or tecla == '4' or tecla == '5' or tecla == '1' or tecla == '3':
			print "########################"
			print "Speed = " + str(speed)
			print "Tita_dot = " + str(tita_dot)

			if direccion == 0:
				print "Direction: fordward."
			else:
				print "Direction: backward."

			print "q to exit."
			print "########################"

		#print("\033[6;3HHello")



	# Enviamos mensajes para finalizar los procesos.	
	in_pC.put('quit')
	out_pC.put('quit')
	
	# Esperar a que finalice.
	p_comunicaciones.join()
	p_odometriaLaser.join()

	print "########################"
	print "q to close Plot."
	print "########################"
	tecla = ''
	while tecla != "q":
		# Leemos la tecla.
		print "Write command: "       
		tecla = in_key()

	in_pP.put('quit')

	# Esperar a que finalice.
	p_plot.join()

	print "\n\n-- END --\n"

# Llamada a la funcion main
if __name__ == '__main__':

    main()
