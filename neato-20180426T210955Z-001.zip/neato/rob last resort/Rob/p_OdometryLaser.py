#!/usr/bin/python
#coding: utf8

"""
Imports de Procesos
"""
"""
Imports
"""
import time

import math

"""
Imports de Procesos
"""
from multiprocessing import Queue
from Queue import Empty



queue_in_g = Queue()
queue_out_g = Queue()
queue_out2_g = Queue()

def inicializar(rbuffer):
	result = []
    	split = rbuffer.split()
    	split_left = split[6].split(",", 1)
    	split_right = split[10].split(",", 1)

    	posR = int(split_right[1])
    	posL = int(split_left[1])
	
	result = []
	result.append(posR)
	result.append(posL)
	return result



def get_odometry(rbuffer, pose, posR, posL):
    #import math
    result = []
    split = rbuffer.split()
    split_left = split[6].split(",", 1)
    split_right = split[10].split(",", 1)
    result.append(int(split_left[1]))
    result.append(int(split_right[1]))

    distancia_R = int(split_right[1])-posR
    distancia_L = int(split_left[1])-posL

    C = (distancia_R+distancia_L)/2
    titaInc = 0
    '''if (abs(distancia_R - distancia_L) > 5):
	titaInc = (distancia_R - distancia_L)/(2*121.5)
    else:
	titaInc = 0'''
    titaInc = (((distancia_R) - (distancia_L)))/(2*121.5)
    pose[0] = pose[0] + C*math.cos(pose[2]) 
    pose[1] = pose[1] + C*math.sin(pose[2])
    pose[2] = (pose[2] + titaInc)%(2*math.pi)
    #print "PoseX = " + str(pose[0])
    #print "PoseY = " + str(pose[1])
    #print "PoseTita = " + str(pose[2])
    #print "Grados = " + str(pose[2]*180/math.pi)

    posR = int(split_right[1])
    posL = int(split_left[1])
	
    result.append(pose)
    #print result
    return result

    #print result
    
def laser_calc(msg, pose):
       print msg
       result = []
       colision_d = True
       tmp = msg.split(',')
       #print " dist en angle 0 : " + str(tmp[4])
       min = 3000
       min_r = 3500
       min_l = 3500
       rot = -1
       angleTr = 400
       for i in range(1, 361):
              dist = int(tmp[3*i + 1])
              if (dist > 0 and dist <= 6000):
                      result.append(pose[0]-95+dist*math.cos(math.radians(i - 1) + pose[2])) 
                      result.append(pose[1]+dist*math.sin(math.radians(i - 1) + pose[2]))
                      if ((i <= 39 or i >= 333)):
                              xChoque = dist*math.sin(math.radians(i-1))
                              if(xChoque < 170):
                                      if(dist < 350):
                                              min = 0
                                      elif (dist < min and min != 0):
                                              #min = abs(dist*math.cos(math.radians(i-1)))
                                              min = dist
                                              angleTr = i-1
                      elif ((i > 39 and i < 129)):
                               if(i< 90):
                                      
                                      xChoque = dist*math.sin(math.radians(90-i-1))
                                      print "distancia angulo xoque " + str(dist) + " " + str(i-1) + " " + str(xChoque) + str(math.cos(math.radians(i-1))) + "\r\n" 
                                      if(xChoque < 170):
                                              if(dist < 350):
                                                      min_r = 0
                                              elif (dist < min_r and min_r != 0):
                                                      min_r = abs(dist*math.cos(math.radians(i-1)))
                               elif(i > 90):
                                      xChoque = abs(dist*math.sin(math.radians(i-1-90)))
                                      if(xChoque < 170):
                                              if(dist < 350):
                                                      min_r = 0
                                              elif (dist < min_r and min_r != 0):
                                                      min_r = abs(dist*math.cos(math.radians(i-1 - 90)))
                               else:
                                      if(dist < 350):
                                              min_r = 0
                                      elif (dist < min_r and min_r != 0):
                                              min_r = dist
                                              
                      elif ((i < 333 and i > 243)):
                               if(i > 270):
                                      xChoque = abs(dist*math.cos(math.radians(360-i-1)))
                                      #print "distancia angulo xoque " + str(dist) + " " + str(i-1) + " " + str(xChoque) + str(math.sin(math.radians(360-i-1))) + "\r\n" 
                                      if(xChoque < 170):
                                              if(dist < 350):
                                                      min_l = 0
                                              elif (dist < min_l and min_l != 0):
                                                      min_l = abs(dist*math.sin(math.radians(360-i-1)))
                               elif(i < 270):
                                      xChoque = abs(dist*math.sin(math.radians(i-1-180)))
                                      if(xChoque < 170):
                                              if(dist < 350):
                                                      min_l = 0
                                              elif (dist < min_l and min_l != 0):
                                                      min_l = abs(dist*math.sin(math.radians(i-1 - 180)))
                               else:
                                      if(dist < 350):
                                              min_l = 0
                                      elif (dist < min_l and min_l != 0):
                                              min_l = dist
                                      
       print "distancia a avançar esquerra " + str(min_r) + "\r\n"
       print "distancia a avançar dreta " + str(min_l) + "\r\n"
                               
       if (min != 0):
               min = math.fabs(min)-350
       if(min_r != 0 and min_l != 0):
               if(min_l > min_r):
                       min_r = min_l
                       rot = 1
       elif(min_l != 0):
               min_r = min_l
               rot = 1
       print "voy a girar a " + str(rot) + "\r\n"
       #if(min_r > 500):
               #min_r = 500
       print "puc avançar recte " + str(min)
       print "angle dist min " + str(angleTr)
       return result, min, rot, (min_r)
       
def cleanCua(out_c):
        while not out_c.empty():
                try:
                        out_c.get()
                except Empty:
                        break
       
def rotateToPoint(pose, pointToGo, out_q): 
        print "Check function\r\n"
        print "Odo: " + str(pose[0]) + "," + str(pose[1]) + "," + str(pose[2]) + "\r\n"
        angleP = 0
        P_x = (pointToGo[0] - pose[0])
        P_y = (pointToGo[1] - pose[1])
        print "Odo: " + str(P_x) + "," + str(P_y) + "\r\n"
        if (P_x != 0 and P_y != 0):
                angleP = math.atan(float(math.fabs(P_y))/float(math.fabs(P_x)))
                print "Angle before: " + str(angleP) + "\r\n"
                angleP = angleP + math.pi*(P_x < 0)*(P_y < 0) + math.pi*0.5*(P_y > 0)*(P_x < 0) + math.pi*1.5*(P_x > 0)*(P_y < 0)
                print "Angle after: " + str(angleP) + "\r\n"
        else:
                if (P_x == 0):
                        if (P_y < 0):
                                angleP = math.pi*1.5
                        else:
                                angleP = math.pi*0.50
                elif (P_y == 0):
                        if (P_x < 0):
                                angleP = math.pi
        if ((angleP - pose[2]) > math.pi):
                ang = ((math.pi*2) - (angleP - pose[2])) * -1
        else:
                ang = (angleP - pose[2])
        distance = ang * 121.5
        
        #cleanCua(out_q)     
       
        comando = 'SetMotor LWheelDist ' + str(-distance) + ' RWheelDist ' + str(distance) + ' Speed ' + str(50) 
        out_q.put(comando)    
        timeMoving =  math.fabs((distance/50) + 0.5)
        time.sleep(timeMoving)
        
        distToGo = math.hypot(P_x, P_y)
        return distToGo
        
def moveToPoint(dist, out_q):
        speed = 200
        comando = 'SetMotor LWheelDist ' + str(dist) + ' RWheelDist ' + str(dist) + ' Speed ' + str(speed)
        out_q.put(comando)    
        timeMoving =  math.fabs((dist/speed) + 2)
        time.sleep(timeMoving)    

def evadeFun(outq, sentido,dist):
        print "Evade entrat \r\n"
        distance = (0.5*math.pi*121.5)*sentido
        comando = 'SetMotor LWheelDist ' + str(distance) + ' RWheelDist ' + str(-distance) + ' Speed ' + str(50)
        cleanCua(outq)
        outq.put(comando)   
        timeMoving =  math.fabs((distance/50)) + 0.5
        time.sleep(timeMoving)
        
        '''distance = dist
        comando = 'SetMotor LWheelDist ' + str(dist) + ' RWheelDist ' + str(dist) + ' Speed ' + str(200)
        timeMoving =  math.fabs((dist/200) + 0.5)
        outq.put(comando)  
        time.sleep(timeMoving)'''
        print "Evade sortir\r\n"
        
def run(queue_in, queue_out, queue_out2):
	
    	global queue_in_g
    	global queue_out_g
    	global queue_out2_g
    	queue_in_g = queue_in
    	queue_out_g = queue_out
    	queue_out2_g = queue_out2
    
	print "#### Start OdometryLaser Process."
	
	S = float(queue_in.get())
	print "#### OdometryLaser Process: S = " + str(S)

	print '#### OdometryLaser Process: Started.'
	
	x_r_last = 999.9
	y_r_last = 999.9
	tita_dot = 0
        n_times_odo = 0
        n_times_laser = 0
        datosLaser = []
        pos_robot = [0, 0]
        queue_out2.put(pos_robot)
        

	queue_out.put('Odo')
        #queue_out.put('Laser')
	pose = []
	pose.append(0)
	pose.append(0)
	pose.append(0)

	result = inicializar(queue_in.get())	
	posR = result[1]
	posL = result[0]
        timeGoing = 0
        timeEvading = 0
        
        #goToPoint = False
        #evadeTime = False
        last_msg_laser = ""
        pointToGo = []
        distToMove = 0
        
        '''timeToPrint = time.time()
        timeToOdo = time.time() - 1
        timeToLaser = time.time() - 2
        print timeToPrint'''
	
	while True:

		try:                                      
                        msg = queue_in.get() #Si es bloquejant no podem fer res                  
			#msg = queue_in.get_nowait()
			#start_total = time.time()
                        print str(msg) + "\r\n"

		except Empty:
			
			#print '#### OdometryLaser Process: Nothing.'
			pass
		
		else:
                
			#print "#### OdometryLaser Process: msg -> " + msg

			if msg == 'quit':
				
				break
                        elif len(msg) == 2:
                                print "Robot has changed its position"
                                time.sleep(msg[1])
                                queue_out.put('Odo')
                                #queue_out.put('Laser')
                                
                        elif len(msg) == 3:
                                #goToPoint = True
                                pointToGo = []
                                pointToGo.append(msg[0])
                                pointToGo.append(msg[1])
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                #Girar
                                distToGo = rotateToPoint(pose, pointToGo, queue_out)
                                
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                #Laser
                                queue_out.put('Laser')
                                msg = queue_in.get()
                                time.sleep(1)
                                datos_laser, distToMove, rotacion_sentido, evade_dist  = laser_calc(msg, pose)
                                if(distToGo < distToMove):
                                        distToMove = distToGo
                                queue_out2.put(datos_laser)
                                
                                if (distToMove != 0):
                                        moveToPoint(distToMove, queue_out)
                                queue_out.put('Bucle')
                                
                        elif len(msg) == 4:
                                print "Bucle\r\n"
                                
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                #Girar
                                distToGo = rotateToPoint(pose, pointToGo, queue_out)
                                
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                queue_out.put('Odo')
                                print "Pose before" + str(pose) + "\r\n"
                                msg = queue_in.get()
                                
                                #Odometria
                                result = get_odometry(msg[1:], pose, posR, posL)
                                posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                print "Pose after" + str(pose) + "\r\n"
                                
                                #Laser
                                queue_out.put('Laser')
                                msg = queue_in.get()
                                time.sleep(1)
                                datos_laser, distToMove, rotacion_sentido, evade_dist = laser_calc(msg, pose)
                                if(distToGo < distToMove):
                                        distToMove = distToGo
                                queue_out2.put(datos_laser)
                                
                                if (distToMove != 0):
                                        moveToPoint(distToMove, queue_out)
                                else:
                                        evadeFun(queue_out, rotacion_sentido, evade_dist)
                                        queue_out.put('Odo')
                                        print "Pose before" + str(pose) + "\r\n"
                                        msg = queue_in.get()
                                        
                                        #Odometria
                                        result = get_odometry(msg[1:], pose, posR, posL)
                                        posR = result[1]
                                        posL = result[0]
                                        pose = result[2]
                                        pos_robot = [pose[0], pose[1]]
                                        queue_out2.put(pos_robot)
                                        print "Pose after" + str(pose) + "\r\n"
                                        
                                        moveToPoint(evade_dist,queue_out)
                                
                                x_R = math.fabs(pose[0] - pointToGo[0])
                                y_R = math.fabs(pose[1] - pointToGo[1])
                                
                                if not(x_R <= 200 and y_R <= 200):
                                        queue_out.put('Bucle')
                                else:
                                        print "yalleghao\r\n"
                                        
			elif msg[0] == 'O':
                                print "Calculo odometria\r\n"
				n_times_odo = n_times_odo + 1
				# ODO
				msg = msg[1:]
				#print msg
				
				x_r = 0 # Pos X robot
				y_r = 0 # Pos Y robot

				pos_robot = [] # Vector of 2 positions (x, y of robot)
				
				#########################################################################################################################				
			# AFEGIR AQUI CODI ODOMETRIA
				
				x_r_last = pose[0]
				y_r_last = pose[1]
                
		        	result =  get_odometry(msg, pose, posR, posL)
				posR = result[1]
				posL = result[0]
				pose = result[2]
                                pos_robot = [pose[0], pose[1]]
                                queue_out2.put(pos_robot)
                                
                                #queue_out.put('Laser')
				'''pos_robot.append(result[0])
				pos_robot.append(result[1])
				
				x_r = pose[0]
				y_r = pose[1]'''
			#########################################################################################################################
				
				if x_r_last != x_r or y_r_last != y_r:
					
					#queue_out2.put(pos_robot)
					x_r_last = x_r
					y_r_last = y_r
                                '''if n_times_odo > 10:
                                        queue_out.put('Laser')
                                        n_times_odo = 0
                                else:
                                        queue_out.put('Odo')'''
                                
			
			elif msg[0] == 'L':
                                print "calculant laser \r\n"
                                #n_times_laser = n_times_laser +1 
				# Laser
				msg = msg[1:]
				#print msg

				 
				datos_laser = [] # Vector of 720 or fewer positions always but always pair (x, y)
				#########################################################################################################################
				
				# AFEGIR AQUI LA RECONSTRUCIÓ INFORMACIÓ LASER
                                
                                datos_laser, distToMove, rotacion_sentido, evade_dist  = laser_calc(msg, pose)
				
				#########################################################################################################################
                                
                                queue_out2.put(datos_laser) 
				'''if ((time.time() - timeGoing) > 0):
                                        queue_out2.put(datos_laser) 
                                if ((time.time() - timeEvading) > 0 and timeEvading != 0):
                                        goToPoint = True
                                        #queue_out.put('Odo')  '''                                      
                                '''if(n_times_laser >3):
                                        queue_out.put('Odo')
                                        print "he enviat un odo \r\n"
                                        n_times_laser = 0
                                else:'''
                                #queue_out.put('Laser')
			
			#queue_out.put('Odo')
                '''if ((time.time() - timeToPrint) > 3):
                        timeToPrint = time.time()
                        queue_out2.put(pos_robot)
                        queue_out2.put(datos_laser)
                if ((time.time() - timeToOdo) > 2):
                        TimeToOdo = time.time()
                        queue_out.put('Odo')
                if ((time.time() - timeToLaser) > 1):
                        TimeToLaser = time.time()
                        queue_out.put('Laser')'''
                '''if (evadeTime):
                        cleanCua(queue_out)
                        timeEvading = evadeFun(pose, last_msg_laser, queue_out)
                        #queue_out.put('Odo')
                        evadeTime = False
                elif (goToPoint):
                        print str(goToPoint) + "point bool begin if\r\n"
                        cleanCua(queue_out)
                        timeGoing = checkPosition(pose, pointToGo, queue_out)
                        #queue_out.put('Odo')
                        goToPoint = False
                        print str(goToPoint) + "point bool in if\r\n"
                        #queue_out.put('Odo')
                        #queue_out.put('Laser')
                time.sleep(2)
                print str(queue_out.qsize()) + "qsize \r\n"'''
			#print "\nTiempo Total p_OdometryLaser: " + str(time.time() - start_total) + " segundos.\n"
			#print "p_odometryLaser"
                #print str(goToPoint) + "point bool \r\n"
                  
	print "#### Finished OdometryLaser Process."
